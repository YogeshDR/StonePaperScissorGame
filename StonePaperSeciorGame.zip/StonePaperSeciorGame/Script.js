let userscore = 0;
let compscore = 0;

const choices = document.querySelectorAll(".choice")
let msg = document.querySelector("#msg")
let userpara = document.querySelector("#usr-score")
let comppara = document.querySelector("#comp-score")

const genChoice = () => {
    const options = ["paper", "rock", "scissor"]
    let idx = Math.floor(Math.random() * 3);
    return options[idx]

}

const drawGame = () => {
    console.log("Game Draw. Play again")
    msg.innerText = "Game Draw. Play again!";
    msg.style.backgroundColor = "grey";
}

const showWinner=(userwin)=>{
    if(userwin== true){
        console.log("You WIN!")
        userscore++;
        userpara.innerText = userscore;
        msg.innerText = "You win!";
        msg.style.backgroundColor = "green";
    }else{
        compscore++
        comppara.innerText = compscore
        console.log("You loose!")
        msg.innerText = "You Loose!";
        msg.style.backgroundColor = "red";
    }
}

const playgame = (userchoice) => {
    compChoice = genChoice();
    console.log(" comp choice", compChoice);
    let userwin = true
    if (userchoice === compChoice) {
        drawGame();
    } else {
        
        if (userchoice === "rock") {
            if(compChoice === "paper"){
                userwin = false;
            }else{
                userwin = true;
            }
        }else if(userchoice === "paper"){
            //scissor, rock
            if(compChoice === "scissor"){
                userwin = false;
            }else{
                userwin = true;
            }
        }else if(userchoice === "scissor"){
            if(compChoice === "rock"){
                userwin = false;
            }else{
                userwin = true;
            }
        }
        showWinner(userwin)
    }
    
}

choices.forEach((choice) => {

    choice.addEventListener("click", () => {
        const userchoice = choice.getAttribute("id")
        console.log("users choice", userchoice);
        playgame(userchoice)
    })
})
